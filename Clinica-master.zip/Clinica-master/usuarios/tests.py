from django.test import TestCase
from usuarios import views

# Create your tests here.

class TestUsersView(TestCase):
    def setup(self):
        pass
